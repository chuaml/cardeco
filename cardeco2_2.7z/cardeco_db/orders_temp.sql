-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 23, 2019 at 09:37 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cardeco`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders_temp`
--

DROP TABLE IF EXISTS `orders_temp`;
CREATE TABLE IF NOT EXISTS `orders_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertLogId` int(11) NOT NULL COMMENT 'id of which inseted batch data/file',
  `orderId` char(60) NOT NULL COMMENT 'platform given unique Id',
  `billno` char(20) DEFAULT NULL,
  `date` date NOT NULL,
  `dateStockOut` date DEFAULT NULL,
  `orderNum` char(20) NOT NULL,
  `sku` char(60) NOT NULL,
  `trackingNum` char(20) NOT NULL,
  `sellingPrice` decimal(10,2) NOT NULL,
  `status` char(20) NOT NULL,
  `transferCharges` decimal(10,2) DEFAULT NULL,
  `shippingFee` decimal(10,2) DEFAULT NULL,
  `shippingFeeByCust` decimal(10,2) DEFAULT NULL,
  `voucher` decimal(10,2) DEFAULT NULL,
  `platformCharges` char(16) DEFAULT NULL,
  `platformChargesAmount` decimal(10,2) DEFAULT NULL,
  `bankIn` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'directCharges BankIn',
  `cash` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'directCharges Cash',
  `remark` char(255) DEFAULT NULL,
  `profit` decimal(10,2) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `aklee` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderId` (`orderId`),
  KEY `billno` (`billno`)
) ENGINE=MyISAM AUTO_INCREMENT=7406 DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
