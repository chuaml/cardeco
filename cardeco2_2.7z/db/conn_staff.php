<?php 

// Tell PHP that we're using UTF-8 strings until the end of the script
mb_internal_encoding('UTF-8');
 
// Tell PHP that we'll be outputting UTF-8 to the browser
mb_http_output('UTF-8');

/*
*by defining/assigning database name, username and password as constants/variables
*can prevent users or hackers from changing these values.
*define() differs to const, it defines constants at Run time
	while const defines constants at compile time.
*define() can be called within an if() block, while const cannot.
 */
define('DB_ADDRESS','localhost');
define('DB_USERNAME','cardeco_staff');
define('DB_PASSWORD','CCC5VNwzPWD6cD2j');
define('DB_NAME','cardeco');

if ($con=mysqli_connect(DB_ADDRESS,DB_USERNAME,DB_PASSWORD,DB_NAME)) {//connection to database, phpmyadmin.
    //check connection
    if (mysqli_connect_errno()) { //If(!$conn)
    trigger_error('Triggered_Error: Fail to connect database!');
    exit('ERROR : ' . mysqli_connect_error());
    }else{
    //echo 'database connection succeed <br>';
    }
} else {
    trigger_error('Triggered_Error: invalid database info!');
    exit('ERROR : ' . mysqli_connect_error());
}

//common user input validation
function trim_input($data) {
  //$data = strip_tags($data);
  //$data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
  $data = trim($data);
  return $data;
}

function trim_output($data) {
  //$data = strip_tags($data);
  $data = trim($data);
  $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
  return $data;
}

?>